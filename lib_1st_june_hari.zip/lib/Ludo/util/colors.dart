import 'package:flutter/material.dart';

class AppColors {
  static Color home1 = Colors.red;
  static const Color home2 = Colors.green;
  static const Color home3 = Colors.yellow;
  static const Color home4 = Colors.blue;
  static const Color player1 = Colors.red;
  static const Color player2 = Colors.green;
  static const Color player3 = Colors.yellow;
  static const Color player4 = Colors.blue;
  static const Color safeSpot = Color(0xffC0C0C0);
}
