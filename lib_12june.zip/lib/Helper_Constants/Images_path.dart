



class ImagesPath{
   // static const  String rouletteImage = "assets/images/wheel.png";
   static const  String rouletteImage = "assets/images/wheel_1.png";
   static const  String rouletteCenterImage = "assets/images/roulette_center.png";
   static const  String backGroundImage = "assets/images/frame.png";
   static const  String rouletteBorderImage = "assets/images/roulette_border.png";
   static const  String rouletteInsideImage = "assets/images/roulette_inside.png";
   static const  String rouletteWithBackGroundImage = "assets/images/roulette_with_background.png";
   static const  String exitImage = "assets/images/Exit.png";
   static const  String scoreImage = "assets/images/score.png";
   static const  String timerImage = "assets/images/timer.png";
   static const  String winnerImage = "assets/images/Winner.png";
   static const  String coinForeGroundImage = "assets/images/coin_foreground.png";
   static const  String mainLogoImage = "assets/images/mainlogo.png";
   static const  String animationGif = "assets/images/somnew.gif";
   static const  String animationGif2 = "assets/images/3dgifmaker27498.gif";
}
