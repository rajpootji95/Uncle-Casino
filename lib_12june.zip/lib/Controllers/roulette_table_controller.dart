


import 'package:get/get.dart';
import 'package:get/get_rx/get_rx.dart';

class RouletteTableController extends GetxController{

RxMap<String,List> bets = RxMap();
RxMap<String,List> coins = RxMap();

}